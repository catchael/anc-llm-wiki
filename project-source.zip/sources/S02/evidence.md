# S02 來源證據

- 核讀日期：2026-11-21。
- [原始頁面](https://www.bose.com/stories/how-do-noise-cancelling-headphones-work)。
- 核讀範圍：The technology behind noise cancelling headphones；Why noise cancelling still works without music；FAQs。
- 保存形式：短摘錄及閱讀定位，不是完整頁面。

> Noise cancelling headphones can reduce voices

摘要與限制見 [來源紀錄](source.md)。
