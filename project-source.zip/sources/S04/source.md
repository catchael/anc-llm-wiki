---
id: S04
title: "Bai、Pan、Chen（2018）· Active feedforward noise control and signal tracking of headsets"
type: research-abstract
source_url: https://pubmed.ncbi.nlm.nih.gov/29604695/
source_locator: "Abstract；DOI 10.1121/1.5027818"
status: verified-excerpt
verified_on: 2026-11-21
evidence: evidence.md
---
# 耳機前饋式主動降噪研究

## 問題與方法
摘要討論耳機前饋控制的電聲分析與實作，包含主要／次要路徑、數位控制及有效轉換延遲。

## 可支持的結論
摘要明確指出兩條路徑的相對延遲影響降噪，並描述以多速率處理降低次要路徑轉換延遲，以及即時實驗驗證。

## 閱讀限制
本輪只核讀 PubMed 摘要。沒有核對全文圖表、衰減量或完整演算法細節；不據此推論所有耳機的表現。1 ms、36° 等數值是 Wiki 的教學推導，非論文測量結果。

## 原始證據與用途
- [來源](https://pubmed.ncbi.nlm.nih.gov/29604695/)；[限量原文摘錄](evidence.md)。
- [[../../wiki/phase-and-delay]]：連接理想模型與控制路徑問題。
