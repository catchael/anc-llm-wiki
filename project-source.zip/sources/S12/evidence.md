# S12 核讀記錄

2026-11-21 核讀 ICA 論文圖 2、§3.1–3.3，並比對 [RWTH PANDAR 說明](https://www.iks.rwth-aachen.de/forschung/tools-downloads/databases/paths-for-active-noise-cancellation-development-and-research/)。圖 2 界定從耳機播放指令到內側麥克風的路徑。§3.1 的 Acoustic Booth 與 Semi-Anechoic Chamber 說明 4.05 秒對數掃頻、48 kHz 及播放路徑測量。§3.2 說明輸出頻譜除以測試訊號的頻譜，§3.3 說明戴法標記。此處保存自寫定位與轉述，未取用資料檔、圖片或研究音訊。
