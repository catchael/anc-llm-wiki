---
id: S13
title: "Rivera Benois 等（2021）· Sound Pressure Minimization at the Ear Drum for In-Ear ANC Headphones Using a Fixed Feedforward Remote Microphone Technique"
type: primary-research-preprint
source_url: https://arxiv.org/abs/2105.06894
source_locator: "arXiv v1，§2 式 2、§3 Results、§4 Conclusions"
status: verified-excerpt
verified_on: 2026-11-21
evidence: evidence.md
---
# 量到耳機的聲音路徑後，如何求固定權重？

作者以量過的聲學路徑做模擬，選擇能讓耳膜位置預測剩餘聲較小的固定前饋濾波器。研究用 512 個控制權重。設計會把重新戴入後的多組量測放進同一次求解，也限制喇叭漏回外側麥克風時的穩定性。這是固定濾波器的研究例子，結果來自用實測路徑做的模擬。不能當成商用品的內部參數或效能。

[本輪閱讀定位](evidence.md) · [[../../wiki/fan-signal-chain]]
