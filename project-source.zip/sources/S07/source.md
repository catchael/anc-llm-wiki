---
id: S07
title: "Wu、Qiu、Ma、Guo（2016）· Comparison of feedforward, feedback and hybrid structures on an ANC headphone"
type: research-abstract
source_url: https://opus.lib.uts.edu.au/handle/10453/101907
source_locator: "UTS 機構典藏公開摘要"
status: verified-excerpt
verified_on: 2026-11-21
evidence: evidence.md
---
# 同一研究耳機上的三種降噪架構

## 閱讀紀錄
作者用研究用耳機比較前饋、回饋及混合三種架構，在消音室測試。摘要報告該配置下前饋對來聲方向較敏感，混合部分緩解這項問題，且該實驗中效果最好。全文標記封閉，僅引用公開摘要的研究範圍與結果方向。

## 適用範圍
用於 [[../../wiki/microphone-layouts]] 中「同一組設備如何比較」。不據此推估市售耳機的表現，不重用原圖或全文。[公開摘要定位](evidence.md)。
