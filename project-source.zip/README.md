# 耳機降噪：從一聲風扇聲開始

- [離線 HTML 教學](lesson/index.html)
- [Wiki 索引](wiki/index.md)
- [教學大綱](lesson/outline.md)
- [逐頁與來源查核](lesson/audit.md)
- [工作流程與反思](project.md)

執行 `python build.py` 可重建 HTML。GitHub Pages 使用 `main` 分支的根目錄作為發佈來源。
