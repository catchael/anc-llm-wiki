# S10 核讀記錄

2026-11-21 核讀 [Analog Devices 產品頁](https://www.analog.com/en/products/adau1772.html) 的功能列表與總覽。總覽描述類比輸入到數位處理再到類比輸出的路徑，並說明數位端支援濾波、調整音量和混音。應用列表包含降噪耳機。本檔保存自寫摘要與定位。
