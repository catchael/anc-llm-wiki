---
id: S06
title: "OpenStax University Physics Volume 1：16.2、16.5、17.1、17.3"
type: textbook
source_url: https://openstax.org/books/university-physics-volume-1/pages/16-5-interference-of-waves
source_locator: "16.2 式16.4、Problem-Solving Strategy；16.5 式16.13；17.1 式17.1；17.3 式17.11、17.12"
status: verified-excerpt
verified_on: 2026-11-21
evidence: evidence-v2.md
---
# 波動教材：相位、頻率與干涉

## 閱讀範圍
已核讀 [16.2 Mathematics of Waves](https://openstax.org/books/university-physics-volume-1/pages/16-2-mathematics-of-waves) 的正弦波表示與頻率／週期關係，以及 [16.5 Interference of Waves](https://openstax.org/books/university-physics-volume-1/pages/16-5-interference-of-waves) 的線性疊加與同頻等振幅相位差公式。

## 可支持的內容
正弦波可用角頻率與相位描述；兩道同頻等振幅線性波相加時，合成振幅取決於相位差。

## 限制
教材的一維理想模型不能直接當真實耳機的性能曲線。Wiki 另行推導延遲誤差與殘餘聲壓的關係，並清楚標記推導條件。

## 證據與概念
[短摘錄與定位](evidence.md)；[[../../wiki/phase-and-delay]]、[[../../wiki/superposition]]。
S06 是一份教材來源紀錄，目前涵蓋四節；不把不同章節灌算成獨立來源。

## 本輪擴充核讀
已核讀 §17.1 的聲壓模型與聲音／聽覺區別，以及 §17.3 的壓力平方、聲強與對數聲強級關係。[新增摘錄與定位](evidence-v2.md)，原 evidence.md 保留。用於 [[../../wiki/measurement]]、[[../../wiki/speech-residual]]、[[../../wiki/active-and-passive]]。這仍是同一教材來源紀錄，不以章節灌算來源數。
