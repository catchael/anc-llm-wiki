---
id: S10
title: "Analog Devices · ADAU1772 audio codec with processor"
type: manufacturer-technical-documentation
source_url: https://www.analog.com/en/products/adau1772.html
source_locator: "產品總覽、功能列表、應用項目"
status: verified-excerpt
verified_on: 2026-11-21
evidence: evidence.md
---
# 一顆音訊晶片如何把輸入、運算和輸出接在一起

原廠頁列出類比麥克風輸入、類比轉數位電路、數位音訊處理及數位轉類比輸出。它把這些功能整合在為低延遲音訊設計的晶片，並列出降噪耳機應用。這是硬體功能可整合的例子。教學採用方塊分解，硬體型號與範例照片不代表其他耳機的配備。

[本輪閱讀定位](evidence.md) · [[../../wiki/fan-signal-chain]]
