"""Teaching narrative and exercises for the offline presentation."""

SLIDES = [
    ("先看你的耳機", "把耳機戴上，想像你在聽歌，旁邊同時有人說話。歌和旁人的聲音分別從哪裡來？", """
<h2>兩條路都通到耳朵</h2>
<figure class="teaching"><div class="path"><span>手機裡的音樂</span><b aria-hidden="true">→</b><span>耳機的小喇叭</span><b aria-hidden="true">→</b><span>耳朵</span></div><div class="path"><span>旁人說話</span><b aria-hidden="true">→</b><span>外面的空氣</span><b aria-hidden="true">→</b><span>耳朵</span></div><figcaption>每一排從左往右讀。按下暫停，只停掉上面那排的音樂。</figcaption></figure>
<ol><li>音樂由手機交給耳機，由耳機裡的小喇叭播放。</li><li>旁人的聲音在空氣中傳過來。即使按下暫停，這條路仍然存在。</li></ol>
<p>耳機的小喇叭有一片快速來回動的薄膜。它推動空氣，空氣的變化傳到耳朵，你就聽到音樂。</p>
<details><summary>暫停音樂後，哪一路還能聽見？</summary>旁人的聲音還能從外面傳到耳朵。</details>
""", [6]),
    ("戴上耳機，和打開降噪，是兩個動作", "想像你在有風扇的房間。你可以在同一位置，依序比較三次。", """
<ol><li>先不戴耳機，聽風扇聲。</li><li>戴好耳機，關閉降噪，再聽一次。</li><li>維持原本戴法，打開降噪，繼續聽。全程暫停音樂。</li></ol>
<figure class="teaching"><div class="cards"><div><strong>① 不戴</strong><span>直接聽風扇</span></div><div><strong>② 戴好、關降噪</strong><span>多了耳罩的阻隔</span></div><div><strong>③ 戴好、開降噪</strong><span>再加電子降噪</span></div></div><figcaption>① 比 ② 看戴上的差異。② 比 ③ 時維持原本戴法，只切換開關。</figcaption></figure>
<p>第 1 到第 2 次，耳罩的軟墊或耳塞多擋住一部分外界聲音。這叫<strong>被動隔音</strong>。第 2 到第 3 次啟動電子功能，這叫<strong>主動降噪</strong>。英文 Active Noise Cancellation 常縮寫為 <strong>ANC</strong>。</p>
<details><summary>哪兩次能比較電子功能的效果？</summary>第 2 與第 3 次。耳機都戴在原本的位置，變動的是降噪開關。</details>
""", [6, 2]),
    ("聲音怎麼從喇叭傳到耳朵？", "把小喇叭想成一片快速來回動的薄膜。它往前推時，附近空氣被擠得密一點。往後動時，附近空氣又疏一點。", """
<p>一陣比較密、比較疏的變化能向外傳。<strong>聲波</strong>就是傳出去的這種變化。耳邊的空氣一擠一鬆，我們可以記錄它比平常的壓力高多少或低多少，這叫<strong>聲壓變化</strong>。</p>
<p>畫成圖時，橫向表示時間由左到右。中線表示平常的壓力。圖線在中線上方表示當下多擠一點，在下方表示當下少擠一點。</p>
<figure class="teaching"><div class="cards"><div><strong>① 空氣擠一點</strong><span>比平常的壓力高</span><b class="level high">＋</b></div><div><strong>② 回到平常</strong><span>與平常的壓力相同</span><b class="level">0</b></div><div><strong>③ 空氣鬆一點</strong><span>比平常的壓力低</span><b class="level low">−</b></div></div><figcaption>這三格依序記下耳邊的變化。下一頁把更多時刻連成一條線，叫做波形。</figcaption></figure>
<details><summary>線在中線下方代表什麼？</summary>代表壓力比平常低一點。空氣仍然有壓力。</details>
""", [1, 6]),
    ("看懂波形，先抓住快慢和大小", "波形是把耳邊的變化一刻一刻畫下來。用固定重複的聲音練習，先看它多久重複，再看它偏離中線多遠。", """
<figure class="teaching"><div class="wave-examples">
<div><strong>A　原來的波</strong><canvas width="300" height="93" data-cycles="2" data-height="21" aria-label="兩輪起伏，每輪同樣高"></canvas></div>
<div><strong>B　同樣高，重複更快</strong><canvas width="300" height="93" data-cycles="4" data-height="21" aria-label="同一段時間內出現四輪，和 A 同高"></canvas></div>
<div><strong>C　重複一樣快，起伏更大</strong><canvas width="300" height="93" data-cycles="2" data-height="33" aria-label="同一段時間內出現兩輪，比 A 高"></canvas></div>
</div><figcaption>三張圖的左右長度代表同一段時間，上下也使用同一把尺。虛線是平常的壓力。</figcaption></figure>
<ol><li><strong>先從左往右數波峰。</strong> A 有兩個，B 有四個。在同一段時間內，B 重複得更快。每秒重複的次數叫<strong>頻率</strong>。每秒 100 次寫成 100 Hz，讀作 100 赫茲。</li>
<li><strong>再從一個波峰移到下一個波峰。</strong> 這段間隔是一輪所花的時間，叫<strong>週期</strong>。每秒 100 次，一輪就是 1/100 秒，也就是 10 毫秒。一毫秒是千分之一秒。</li>
<li><strong>最後從虛線往上比高度。</strong> A 和 C 都有兩個波峰，但 C 的波峰離虛線更遠。離中線最遠的距離叫<strong>振幅</strong>。</li></ol>
<details><summary>一張圖的波峰更高，能說它重複得更快嗎？</summary>只看高度能比較振幅。要比較頻率，得看同一段時間內重複幾次。</details>
""", [1, 4]),
    ("兩道聲音相遇，先算一個時刻", "在耳邊的同一個位置，如果兩道聲音同時到達，可以把它們在那一刻造成的壓力變化相加。這叫疊加。", """
<figure class="teaching"><div class="equations">
<div><span class="high">＋1 ↑</span><b>＋</b><span class="high">＋1 ↑</span><b>＝</b><strong class="high">＋2 ↑</strong></div>
<div><span class="high">＋1 ↑</span><b>＋</b><span class="low">−1 ↓</span><b>＝</b><strong>0</strong></div>
<div><span class="high">＋1 ↑</span><b>＋</b><span class="low">−0.8 ↓</span><b>＝</b><strong class="high">＋0.2 ↑</strong></div>
</div><figcaption>每排只看一個瞬間。↑ 表示壓力比平常高，↓ 表示比平常低。</figcaption></figure>
<p>先看第二排。第一道讓壓力高 1，第二道讓它低 1，加起來剛好回到平常，這叫<strong>抵消</strong>。再看第三排，第二道少降一點，就留下 0.2。要讓一整段聲音變小，這種配合要延續到後面的時刻。</p>
<details><summary>剛好抵消一個時刻，夠不夠？</summary>還要看後面的每個時刻。如果下一刻兩道都讓壓力升高，結果就會增加。</details>
""", [1]),
    ("動手試出怎樣才會抵消", "上一頁只算了一個時刻。現在把兩道波分成上下兩排，再把加出來的結果放在第三排。每排都從左往右看時間。", """
<figure class="teaching"><canvas id="wave" width="520" height="290" aria-label="第一道波、第二道波、兩者相加，各畫在一排"></canvas><figcaption>沿圖上的直線往下看，同一直線穿過的三排代表同一時刻。每排的虛線是自己的零線。</figcaption></figure>
<p>用一整圈 360° 代表重複一輪。兩道波錯開多少叫<strong>相位差</strong>。0° 沒錯開，90° 錯開四分之一輪，180° 錯開半輪。</p>
<div class="row" aria-label="直接嘗試三種位置"><button type="button" data-phase="0">0° 沒錯開</button><button type="button" data-phase="90">90° 四分之一輪</button><button type="button" data-phase="180">180° 半輪</button></div>
<label for="phase">也可以拖動滑桿調整錯開量</label><br><input id="phase" type="range" min="0" max="180" value="0"><p id="result" aria-live="polite"></p>
<ol><li>點 0°，沿直線讀到「高＋高」，第三排的波峰變成兩倍高。</li><li>再點 180°，看同一條線變成「高＋低」，第三排變平。</li><li>點 90°，第三排還有起伏，表示還沒完全抵消。</li></ol>
<p>這個練習使用兩道同樣高、重複得一樣快的波。下一頁來看耳機怎麼做出第二道聲音。</p>
""", [1, 4]),
    ("耳機怎麼做出抵消聲？", "有一種做法是把收聲用的麥克風放在耳機外側，先取得外界聲音的資訊。麥克風就像手機的錄音元件。", """
<ol><li>外界噪音一邊傳向耳朵，一邊被麥克風收進來。</li><li>耳機裡負責運算的電子元件根據收進來的資訊，決定小喇叭要怎麼動。</li><li>喇叭播放<strong>補償聲</strong>，也就是用來減少外界聲的另一道聲音。</li><li>兩道聲音抵達耳邊，在同一位置相加。對得越準，剩下的聲音才可能越小。</li></ol>
<figure class="teaching"><div class="path"><span>外界噪音</span><b aria-hidden="true">→</b><span>直接傳過來</span><b aria-hidden="true">→</b><span>耳邊</span></div><div class="path long-path"><span>外界噪音</span><b aria-hidden="true">→</b><span>麥克風收聲</span><b aria-hidden="true">→</b><span>耳機運算</span><b aria-hidden="true">→</b><span>喇叭發出補償聲</span><b aria-hidden="true">→</b><span>耳邊</span></div><figcaption>先讀上排外界聲，再讀下排補償聲怎麼做出來。兩路都在耳邊相遇。</figcaption></figure>
<p>收聲的位置離耳朵有一段距離。運算、喇叭發聲和空氣傳遞也需要時間。因此麥克風錄到的變化，還得配合抵達耳邊的時間與大小。這類用外側資訊預先補償的做法叫<strong>前饋</strong>。</p>
<details><summary>耳機應該在哪裡做到兩道聲音相加變小？</summary>目標是耳朵附近。麥克風收聲的位置只是提供資訊。</details>
<p>想跟著同一聲風扇聲看每個零件怎麼接手？<a href="#17">從第 17 頁開始看完整路徑和算例</a>。</p>
""", [2, 4]),
    ("晚一點點，為什麼也會有差？", "延遲就是晚到的時間。假設補償聲本來對準得剛剛好，現在額外晚到 1 毫秒。重複得越快，一毫秒就會佔一輪越大一段。", """
<figure class="teaching"><div class="time-example"><strong>100 Hz 的一輪有 10 格</strong><div class="time-grid ten" aria-label="十格，第一格著色"><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span></div><strong>500 Hz 的一輪只有 2 格</strong><div class="time-grid two" aria-label="兩格，第一格著色"><span></span><span></span></div></div><figcaption>每格都是 1 毫秒，兩排格子的寬度相同。看著色的一格佔整排多少，就知道晚到的時間佔一輪多少。</figcaption></figure>
<table><thead><tr><th>重複速度</th><th>一輪多久</th><th>1 毫秒佔一輪多少</th></tr></thead><tbody><tr><td>100 Hz</td><td>10 毫秒</td><td>十分之一</td></tr><tr><td>500 Hz</td><td>2 毫秒</td><td>一半</td></tr></tbody></table>
<p>如果本來是波峰對波谷，補償聲再晚半輪，波谷的位置就可能變成波峰。兩個一樣大的波反而會加在一起。</p>
<p>這是為了看清時間如何影響抵消的算例。要知道某一款耳機真的能減少多少，還要看它的實際測量。</p>
<details><summary>同樣晚 1 毫秒，哪一個例子錯開的輪數較多？</summary>500 Hz。一輪只要 2 毫秒，晚 1 毫秒就錯開半輪。</details>
""", [4]),
    ("為什麼還是聽得懂隔壁說話？", "說話時，每個字的聲音不一樣。一句話可能有較低的嗡嗡聲、較高的嘶聲，也有停頓。耳機可能讓其中一些部分變小，另一些仍清楚。", """
<p>想像你戴著耳機，房間的風扇一直開著，朋友在同一個位置說話。開啟降噪後，風扇小聲了，朋友也稍微小聲了，你卻仍然聽得懂。下面用同一句話比較開啟前後。</p>
<figure class="teaching"><div class="cards"><div><strong>開啟前</strong><span>風扇嗡嗡聲明顯</span><span>聽得懂「要喝水嗎？」</span></div><div><strong>開啟後</strong><span>風扇聲小很多</span><span>人聲也小了，仍聽得懂那句話</span></div></div><figcaption>這是可能出現的情境。先比較同一種聲音前後，再問句子能不能聽懂。</figcaption></figure>
<p>要問<strong>人聲變小了多少</strong>，得比較開關前後的聲音。要問<strong>還能聽懂幾個字</strong>，得請人辨認說了什麼。這兩個問題需要不同的觀察。</p>
<details><summary>「我還聽得懂」可以告訴我們什麼？</summary>還留有足夠的線索讓你理解那句話。要知道減少多少，仍得量開關前後的差異。</details>
""", [3, 5]),
    ("怎麼公平地量出差異？", "如果關掉時耳罩戴得很鬆，打開時又戴緊了，你同時改了兩件事。重新比較時，應該只改想知道的那一件。", """
<p>先讓同一台喇叭在同一位置播放相同的測試聲。讓放在耳朵位置的麥克風記錄三次。第一個數字是沒有耳機的基準。第二、三個數字是同一戴法下關閉及開啟降噪。</p>
<p><strong>分貝（dB）</strong>是記錄聲音等級的一種刻度。在這個例子中，數字較小表示測到較低的聲音等級。先用相減看少了幾分貝。</p>
<figure class="teaching"><div class="cards"><div><strong>① 不戴</strong><span class="meter">70 dB</span></div><div><strong>② 戴好、關降噪</strong><span class="meter">60 dB</span></div><div><strong>③ 戴好、開降噪</strong><span class="meter">45 dB</span></div></div><figcaption>假設數字。先遮住 ①，只用 ② 和 ③ 算出開關差異。</figcaption></figure>
<details><summary>開關的額外差異是 25 還是 15 dB？</summary>60 − 45 = 15 dB。70 − 45 = 25 dB 則包含戴耳機的物理阻隔。</details>
""", [2, 5]),
    ("頻率曲線到底在畫什麼？", "測量時，把低音到高音的各個頻率排成一列，再把每個頻率減少了多少寫在對應位置。把這些點畫成線，就是一條顯示不同頻率效果的曲線。", """
<p>先讀一份假設數據。第一欄是每秒重複幾次，第二欄是開啟降噪後額外少了幾分貝。</p>
<table><thead><tr><th>頻率</th><th>開關差異</th></tr></thead><tbody><tr><td>100 Hz</td><td>20 dB</td></tr><tr><td>1,000 Hz</td><td>5 dB</td></tr><tr><td>4,000 Hz</td><td>1 dB</td></tr></tbody></table>
<figure class="teaching"><canvas id="frequency-curve" width="360" height="245" aria-label="橫軸是頻率。100 Hz 對應 20 dB，1000 Hz 對應 5 dB，4000 Hz 對應 1 dB。"></canvas><figcaption>先看圖下方的頻率，再沿橘色虛線往上找點，最後往左讀 20 dB。橘色虛線示範的是 100 Hz。</figcaption></figure>
<p>沿下方找到 100 Hz，再往上找到線上的第一個點。從點的高度往左讀到 20 dB。點之間的線用來看出方向。讀其他曲線時也要先看基準，有些圖用裸耳當基準。</p>
<details><summary>哪個頻率在這組例子的開關差異最大？</summary>100 Hz。這張表只能回答表內三個測試點，以及這個比較基準的問題。</details>
""", [5]),
    ("麥克風放在哪裡，會聽到什麼？", "把耳罩想成一道門。門外是外界噪音，門內有小喇叭和你的耳朵。先看圖上亮色圓點在哪一側，再看名稱。", """
<figure class="teaching"><div class="cards mic-cards">
<div><strong>前饋</strong><div class="mic-map" aria-label="外側有降噪麥克風"><span class="has-mic">外側</span><span>內側</span></div><span>先取得門外的聲音資訊，再決定怎麼發出補償聲。</span></div>
<div><strong>回饋</strong><div class="mic-map" aria-label="內側有降噪麥克風"><span>外側</span><span class="has-mic">內側</span></div><span>聽門內剩下什麼，將讀數送回去調整喇叭。</span></div>
<div><strong>混合</strong><div class="mic-map" aria-label="內側及外側都有降噪麥克風"><span class="has-mic">外側</span><span class="has-mic">內側</span></div><span>同時使用門外的聲音資訊與門內的讀數。</span></div>
</div><figcaption>亮點代表典型的降噪麥克風位置，中線是耳罩的分界。每張卡只畫降噪用途。</figcaption></figure>
<p>回饋像一圈「收聲 → 調整 → 再收聲」。內側麥克風也可能收到耳機播放的音樂，電子系統要一併處理。</p>
<details><summary>想讓耳機知道耳罩裡還剩什麼聲音，應該在哪邊收聲？</summary>內側。若同時使用外側資訊，就是混合做法。</details>
""", [7]),
    ("耳罩裡兩個位置，會聽到一樣嗎？", "內側麥克風可能在小喇叭旁邊，你的耳道入口則在另一處。先找圖中的 A 和 B。", """
<figure class="teaching"><div class="cards"><div><strong>A　內側麥克風</strong><span>可能靠近耳機的小喇叭</span></div><div><strong>B　耳道入口</strong><span>佩戴者耳邊的另一個位置</span></div></div><figcaption>A 和 B 是兩個收聲位置。每處都是外界聲和補償聲相加後的結果，兩處的聲音走法和讀數可能不同。</figcaption></figure>
<div class="research-note"><strong>研究是怎麼比的？</strong><p>一組研究比較同一副研究耳機的三種架構，將測試放在盡量減少聲音反射的消音室。公開摘要報告，在那組條件下，前饋較受聲音來向影響，混合有助於減輕這項影響，且該次表現最好。</p><p>另一篇研究在假人頭部的耳位檢查讀數。想比較市售耳機時，應先確認測試條件和耳位結果。</p></div>
<details><summary>只知道「麥克風 A 收到的聲音較小」，可以直接當成 B 的數字嗎？</summary>先確認測量位置。A 的讀數代表 A 所在處，想知道 B 要看耳位的量測。</details>
""", [7]),
    ("風聲是從樹那邊來，還是在耳機旁產生？", "想像你站在樹旁，先聽到遠處葉子沙沙響，接著感到風直接吹過耳罩。兩種情況值得分開看。", """
<figure class="teaching"><div class="cards"><div><strong>遠處的聲音</strong><span>風推動樹葉 → 樹葉發聲 → 聲音傳到耳朵</span></div><div><strong>耳罩旁的氣流</strong><span>風掠過外側麥克風 → 收音點的壓力起伏 → 耳機可能把它當噪音補償</span></div></div><figcaption>先比較聲音或壓力變化的起點。右欄的起伏就在收音位置附近。</figcaption></figure>
<p>在某些設備和模式下，補償可能讓人聽到額外的低沉風聲。<strong>RTINGS</strong> 是做產品測試與評測的網站，會實際測量耳機並公開測法。他們用風扇從不同角度吹耳機，再比較風聲。要解讀結果，先確認測的是哪副耳機、哪個模式，以及風從哪裡吹來。</p>
<details><summary>想知道走路時風吹過耳罩怎樣，該找哪種測試？</summary>找有控制來風條件的風噪測試，再看你使用的模式是否在測試範圍內。</details>
""", [8]),
    ("測降噪，要從聲音一開始就記嗎？", "如果一段背景聲剛播出，你可以馬上記錄，也可以先讓耳機有時間調整。這兩個觀察時點回答不同問題。", """
<figure class="teaching"><div class="path"><span><strong>0 秒</strong><br>開始播測試聲</span><b aria-hidden="true">→</b><span>先讓耳機聽一段時間</span><b aria-hidden="true">→</b><span><strong>5 秒後</strong><br>開始記錄</span></div><figcaption>這是 RTINGS 的 v1.7 測法案例。沿箭頭讀，五秒是從開始播到開始記錄。</figcaption></figure>
<p><strong>粉紅噪音</strong>是一種可以持續播放、同時含有許多高低音的測試聲。它怎麼分配能量？把頻率按「翻一倍」分段，每段分到的總能量一樣。</p>
<div class="cards"><div><strong>100 到 200 Hz</strong><span>從 100 翻到兩倍</span></div><div><strong>200 到 400 Hz</strong><span>從 200 翻到兩倍</span></div></div>
<p>上面兩段的總能量相同。測試者播放同一種聲音，就能分段比較耳機讓哪些頻率變小。街道、辦公室或機艙錄音則用來看耳機遇到這些生活聲音時的表現。</p>
<p>第 8 頁的一毫秒用來計算一道波錯開多少。這裡的五秒是測試開始記錄前留給耳機調整的時間。</p>
<details><summary>想看一陣噪音剛出現時的效果，要從哪一刻記？</summary>從聲音出現時開始記，才能看到最初的變化。</details>
""", [8, 4]),
    ("少 20 dB，耳邊的聲壓剩下多少？", "第 11 頁的圖上讀到 20 dB。分貝用比例計算。先把開啟前的聲壓大小想成 100 格，再看看兩種差異各會剩幾格。", """
<figure class="teaching"><div class="pressure-compare"><div><strong>開啟前</strong><div class="pressure-bar"><span style="--remain:100%"></span></div><span>100 格</span></div>
<div><strong>少約 6 dB</strong><div class="pressure-bar"><span style="--remain:50%"></span></div><span>約 50 格</span></div>
<div><strong>少 20 dB</strong><div class="pressure-bar"><span style="--remain:10%"></span></div><span>10 格</span></div></div><figcaption>每排最長都是 100 格。著色長度是同一量測條件下留下的聲壓比例。</figcaption></figure>
<p>例如 65 降到 45 dB，差 20 dB。60 降到 40 dB 也是同樣的差。兩者換算後都剩開啟前聲壓的十分之一。感覺有多大聲，需要另外觀察。</p>
<details><summary>第 11 頁的 100 Hz 少 20 dB，這個條件下大約剩幾格？</summary>10 格。這是聲壓比，用來解讀指定的頻率與量測條件。</details>
""", [5]),
    ("跟著一聲風扇聲走進耳機", "戴好耳機，暫停音樂。追蹤風扇嗡聲中的一小段。先看它穿過耳罩的路，再看耳機如何沿另一條路做出補償聲。", """
<figure class="teaching">
<p><strong>上路｜外界聲自己走</strong></p>
<div class="path"><span>風扇發聲</span><b aria-hidden="true">→</b><span>穿過耳罩等路徑</span><b aria-hidden="true">→</b><span>耳邊的原聲</span></div>
<p><strong>下路｜耳機用收音做出補償聲</strong></p>
<ol class="signal-steps">
<li><strong>外側麥克風</strong><span>風扇聲 → 會變動的電訊號</span></li>
<li><strong>類比轉數位電路（ADC）</strong><span>隔固定時間記一筆數字，每筆叫樣本</span></li>
<li><strong>數位訊號處理器（DSP）</strong><span>用目前和先前的數字算出播放指令</span></li>
<li><strong>數位轉類比電路（DAC）與功率放大</strong><span>轉成電訊號，再提供帶動喇叭的電力</span></li>
<li><strong>小喇叭</strong><span>薄膜來回推空氣，補償聲傳到耳邊</span></li>
</ol>
<figcaption>先從上路左端追到耳邊，再按 1 到 5 走下路。到第 5 步才有空氣中的補償聲，兩路在耳邊相加。這是外側收音的數位前饋示意，幾種電子功能可以整合在同一顆晶片。</figcaption>
</figure>
<details><summary>從哪一步開始，電訊號成為一筆筆數字？</summary>第 2 步。類比轉數位電路每隔固定時間記一次，後面的處理器才有數字可算。</details>
""", [9, 2]),
    ("先量耳機小喇叭：0.4 怎麼來？", "先把風扇停掉，只用耳機的小喇叭發出已知的測試聲。在要檢查的位置放一支麥克風，記下它收到什麼、晚了多久。", """
<figure class="teaching">
<div class="path"><span>已知播放讀數 <strong>10</strong></span><b aria-hidden="true">→</b><span>電路、喇叭、空間</span><b aria-hidden="true">→</b><span>測點收到 <strong>4</strong></span></div>
<figcaption>課堂假想量測。先把時間對齊，只看一個頻率的大小。右邊 4 除以左邊 10，得到 <strong>0.4</strong>。到達時間另記。</figcaption>
</figure>
<div class="research-note"><strong>研究實際怎麼做？</strong><p>RWTH 團隊用 Bose QC20 耳機硬體和外接設備，播放從低音逐步變高的測試聲，叫做<strong>掃頻</strong>。其中一組掃頻長 4.05 秒，每秒記下 48,000 筆。研究把各頻率送出與收到的變化拿來比較，能看出一條路徑在不同頻率的大小和到達時機。</p><p>研究繞開了原廠降噪電路，公開的是聲音路徑。前面的 0.4 是這堂課從假想讀數算出的單一比例。</p></div>
<details><summary>為什麼同時需要記下大小與到達時間？</summary>即使大小剛好，補償聲到了不同時刻，也可能錯過要抵消的那一刻。</details>
""", [9]),
    ("再開風扇：用兩筆量測求出兩個權重", "保持同一戴法、關閉補償，讓同一台風扇繼續吹。同步記下外側麥克風和目標測點的讀數。先問測點要抵消多少，再用上一頁的 0.4 反推喇叭要送多少。", """
<figure class="teaching">
<div class="cards"><div><strong>時刻 A</strong><span>外側現在 +4、前一筆 +2。</span><span>測點的風扇聲 +1.0，要補 −1.0。</span><span>喇叭要送 −1.0 ÷ 0.4 ＝ <strong>−2.5</strong>。</span></div>
<div><strong>時刻 B</strong><span>外側現在 +2、前一筆 +4。</span><span>測點的風扇聲 +0.8，要補 −0.8。</span><span>喇叭要送 −0.8 ÷ 0.4 ＝ <strong>−2.0</strong>。</span></div></div>
<figcaption>兩組是假想量測。從每欄的測點風扇聲往下讀，先翻方向，再除以播放路徑的比例。只看 A，會有很多對權重都能算出 −2.5，所以再用 B 一起決定。</figcaption>
</figure>
<p><strong>權重</strong>就是現在與前一筆各要乘多少。讓兩組讀數都算對，可以求出同一對權重 <strong>−0.5、−0.25</strong>。播放時把每筆數字乘各自的權重再相加，這裡只用兩筆的規則就是一種 <strong>FIR 濾波器</strong>。</p>
<details><summary>看這兩個權重怎麼解出來</summary>
<p>把現在的權重叫 a，前一筆的叫 b。A 給出 4a＋2b＝−2.5，B 給出 2a＋4b＝−2.0。把 B 的兩邊乘以二，再減去 A，a 就消掉，剩下 6b＝−1.5。所以 b＝−0.25。把 b 代回 A，就得到 a＝−0.5。</p>
<p>驗算 A：+4 × (−0.5) ＋ +2 × (−0.25)＝−2.5。經播放路徑乘 0.4，測點才收到 −1，跟原聲 +1 相加剩 0。如果只把外側 +4 翻成 −4，測點收到 −1.6，兩路相加反而還剩 −0.6。</p>
</details>
<div class="research-note"><strong>實務怎麼選？</strong><p>Rivera Benois 等人的固定前饋研究用實測路徑模擬，以降低耳膜位置的預測剩餘聲為目標，求一組 512 個控制權重。研究還比較用多次重新戴入的資料一起求解。固定做法在播放時使用這組求好的權重。</p></div>
""", [9, 2, 4]),
    ("重新戴一次，耳機怎麼調整原來的權重？", "有些設計會用內側麥克風量兩道聲音相加後剩多少。接續前兩頁：風扇還在，假想這次重新戴好後，播放路徑變弱。", """
<figure class="teaching"><div class="cards">
<div><strong>① 路徑估計改變</strong><span>假設同樣送出 10，現在只量到 3.2，模型從 0.4 變成 <strong>0.32</strong>。</span></div>
<div><strong>② 用舊權重量剩餘</strong><span>原指令 −2.5，乘 0.32 後收到 −0.8。原聲仍取 +1，量到剩 <strong>+0.2</strong>。</span></div>
<div><strong>③ 微調兩個權重</strong><span>先用新路徑修正兩筆外側讀數成 1.28、0.64，再把剩餘 +0.2 和它們一起用來微調。</span></div>
</div><figcaption>按 ① → ③ 看。這是時間已對齊、且已取得新路徑估計的教學例子。量路徑和用剩餘聲調權重是兩個步驟，何時重測由設計決定。</figcaption></figure>
<p>這種把播放路徑也算進權重更新的方法叫 <strong>FxLMS</strong>。送給喇叭的指令仍由原本的外側讀數乘各自的權重算出來。Bai 等人的耳機研究摘要比較了固定和自動調整的控制器。</p>
<details><summary>用 A 的 +4、+2 手算一次微調</summary>
<p>先把兩筆外側讀數乘 0.32：4 × 0.32＝1.28，2 × 0.32＝0.64。假設每次調整尺度（步長）是 0.1。</p>
<p>現在的權重：−0.5 − 0.1 × 0.2 × 1.28＝<strong>−0.5256</strong>。前一筆：−0.25 − 0.1 × 0.2 × 0.64＝<strong>−0.2628</strong>。</p>
<p>用相同的 +4、+2 和原聲 +1 做對照試算，新指令是 −2.628。乘 0.32 後加回原聲，剩 +0.15904，約 <strong>+0.16</strong>。實際下一刻會收到新數字，所以即時效果要再看讀數。</p>
</details>
<details><summary>量到 0.32，等於已經換好兩個權重嗎？</summary>0.32 描述喇叭到測點的變化。兩個權重還要用外側讀數和量到的剩餘聲來調。</details>
""", [9, 7]),
    ("用自己的話，把整條過程說一遍", "回到第一頁的耳機。你不播音樂，也聽到風扇或說話聲。試著把耳罩、麥克風、喇叭和耳朵串成一個解釋。", """
<figure class="teaching"><div class="path long-path"><span>外面有聲音</span><b aria-hidden="true">→</b><span>耳罩擋住一部分</span><b aria-hidden="true">→</b><span>開啟降噪後加上補償聲</span><b aria-hidden="true">→</b><span>耳邊還可能有剩下的聲音</span></div><figcaption>沿圖說一遍，再打開下面的答案核對。</figcaption></figure>
<details><summary>第一題：關掉降噪，為什麼戴上仍可能變安靜？</summary>耳罩或耳塞仍在聲音傳入的路上，提供被動隔音。</details>
<details><summary>第二題：為什麼多播放一道聲音可以讓耳邊變安靜？</summary>兩道聲音在耳邊相加。若原來使壓力上升的時候，補償聲恰好讓壓力降低，合起來的變化就較小。</details>
<details><summary>第三題：低鳴變小，人聲仍聽懂，表示降噪失效嗎？</summary>單憑聽懂人聲無法判斷。先比較開關是否改變聲音，再問哪一些頻率減少、這些差異是否影響辨認句子。</details>
<details><summary>第四題：頁面寫「混合」，下一步要看什麼才能比較效果？</summary>先看量測位置、開關和戴法是否一致，再按自己關心的問題找全頻、生活情境或風噪測試。</details>
<details><summary>第五題：處理器算出 −2.5，接著哪些部分把它變成補償聲？</summary>數位轉類比電路把數字轉成電訊號，放大電路提供所需電力，小喇叭推動空氣。聲音傳到耳邊之後，再與原聲相加。</details>
<p>可以回到任何一頁重新試算，或點下面的 Wiki 開始完整閱讀。</p>
""", [6, 1, 2, 3, 5, 7, 8, 9]),
]
