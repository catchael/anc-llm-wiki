# S06 擴充核讀證據

- 日期：2026-11-21；承接 evidence.md，不覆寫舊摘錄。
- [§17.1 Sound Waves](https://openstax.org/books/university-physics-volume-1/pages/17-1-sound-waves)：核讀聲音與聽覺區別、聲壓波模型，式17.1。
- [§17.3 Sound Intensity](https://openstax.org/books/university-physics-volume-1/pages/17-3-sound-intensity)：核讀式17.11、17.12，壓力平方與聲強關係、對數聲強級。
- 保存形式：短摘錄與定位，不是完整章節。聲壓比的分貝換算由以上關係自行推導。

§17.1 短摘錄：
> Hearing is the perception of sound

§17.3 短摘錄：
> the intensity of a sound wave is related to its amplitude squared
