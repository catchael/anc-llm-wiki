# 來源證據：S04

- 取得／核讀日期：2026-11-21。
- URL：https://pubmed.ncbi.nlm.nih.gov/29604695/
- 定位：Abstract 第二段開頭；閱讀範圍為摘要，未讀全文。
- 保存形式：短摘錄，不是整頁或全文快照；其餘內容回來源核對。

> the relative delay of the primary path and the secondary path is crucial to the noise reduction performance
