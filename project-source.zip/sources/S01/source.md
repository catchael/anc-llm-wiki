---
id: S01
title: "OpenStax Physics §13.3"
type: textbook
source_url: https://openstax.org/books/physics/pages/13-3-wave-interaction-superposition-and-interference
source_locator: "Superposition of Waves；Wave Interference；圖13.11–13.13"
status: verified-excerpt
verified_on: 2026-11-21
evidence: evidence.md
---
# OpenStax Physics §13.3

## 閱讀紀錄與用途
核讀線性疊加、同相／反相、一般干涉與位置差異。教材提供基本原理，沒有測量真實耳機。用於 [[../../wiki/superposition]]。

## 可追溯性與限制
[線上來源](https://openstax.org/books/physics/pages/13-3-wave-interaction-superposition-and-interference)；[保存的短摘錄](evidence.md)。定位：Superposition of Waves；Wave Interference；圖13.11–13.13。已核讀列出的段落，保存的是短摘錄與定位，並非整頁或全文快照。來源支持原理或方法；Wiki 中的數值算例與實驗提案另行標明，不能冒充來源實測。
