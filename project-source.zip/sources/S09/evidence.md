# S09 來源定位

2026-11-21 核讀 [RTINGS 測法開發文](https://www.rtings.com/headphones/learn/research/noise-isolation)。在 Adapting Our Testing For Delayed ANC 核對測試訊號、五秒準備時段和情境錄音。在 Different Types Of ANC Implementation 與 What Causes Wind Noise? 核對麥克風位置及氣流造成的局部壓力變化。保留自寫摘要與定位。規格圖、品牌照片、音訊及媒體範例均未複製。
