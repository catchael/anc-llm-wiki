# S01 來源證據

- 核讀日期：2026-11-21。
- [原始頁面](https://openstax.org/books/physics/pages/13-3-wave-interaction-superposition-and-interference)。
- 核讀範圍：Superposition of Waves；Wave Interference；圖13.11–13.13。
- 保存形式：短摘錄及閱讀定位，不是完整頁面。

> The superposition of most waves that we see in nature produces a combination of constructive and destructive interferences.

摘要與限制見 [來源紀錄](source.md)。
