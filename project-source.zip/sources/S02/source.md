---
id: S02
title: "Bose · How do noise cancelling headphones work?"
type: manufacturer-webpage
source_url: https://www.bose.com/stories/how-do-noise-cancelling-headphones-work
source_locator: "The technology behind noise cancelling headphones；Why noise cancelling still works without music；FAQs"
status: verified-excerpt
verified_on: 2026-11-21
evidence: evidence.md
---
# Bose · How do noise cancelling headphones work?

## 閱讀紀錄與用途
核讀主動／被動分工、貼合、無音樂運作及人聲 FAQ。這是廠商原理解說，不是跨產品性能保證；未採用宣傳性優劣比較。用於 [[../../wiki/active-and-passive]]、[[../../wiki/speech-residual]]。

## 可追溯性與限制
[線上來源](https://www.bose.com/stories/how-do-noise-cancelling-headphones-work)；[保存的短摘錄](evidence.md)。定位：The technology behind noise cancelling headphones；Why noise cancelling still works without music；FAQs。已核讀列出的段落，保存的是短摘錄與定位，並非整頁或全文快照。來源支持原理或方法；Wiki 中的數值算例與實驗提案另行標明，不能冒充來源實測。
