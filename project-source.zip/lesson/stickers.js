// Original pictograms drawn for the offline lesson. The text and teaching figures
// carry the same information for readers who cannot see these decorative stickers.
function drawSticker(canvas, page) {
 const kind = ['headphones','fan','speaker','wave','wave','wave','mic','clock','speech',
  'chart','chart','mic','headphones','wind','clock','chart','fan','wave','speaker','mic','headphones'][page - 1];
 const ctx = canvas.getContext('2d');
 const palettes = {
  headphones:['#efdff9','#9767b2'], fan:['#d9efed','#4d998d'], speaker:['#ffe8cc','#d47c48'],
  wave:['#dcf2e4','#37806d'], mic:['#ffe6d3','#bd6747'], clock:['#f8edce','#b88731'],
  speech:['#fbe1e9','#ba5779'], chart:['#deecfb','#557fb2'], wind:['#d9f0f7','#4d91a8']
 };
 const [paper, accent] = palettes[kind];
 const ink = '#233c45';
 const path = (points, color = ink, width = 3) => {
  ctx.beginPath();
  points.forEach(([x, y], i) => i ? ctx.lineTo(x, y) : ctx.moveTo(x, y));
  ctx.strokeStyle = color; ctx.lineWidth = width; ctx.stroke();
 };
 const circle = (x, y, r, fill) => {
  ctx.beginPath();ctx.arc(x, y, r, 0, 2 * Math.PI);
  ctx.fillStyle = fill;ctx.fill();ctx.strokeStyle = ink;ctx.lineWidth = 2;ctx.stroke();
 };
 const box = (x, y, w, h, radius, fill, outline = ink) => {
  ctx.beginPath();ctx.roundRect(x, y, w, h, radius);
  ctx.fillStyle = fill;ctx.fill();ctx.strokeStyle = outline;ctx.lineWidth = 2;ctx.stroke();
 };
 ctx.lineCap = 'round';ctx.lineJoin = 'round';
 box(7, 8, 106, 91, 28, paper, '#fff');
 path([[20,25],[20,35]],accent,2);path([[15,30],[25,30]],accent,2);
 path([[100,73],[100,83]],accent,2);path([[95,78],[105,78]],accent,2);
 switch (kind) {
  case 'headphones':
   ctx.beginPath();ctx.arc(60, 53, 24, Math.PI, 2 * Math.PI);
   ctx.strokeStyle = ink;ctx.lineWidth = 6;ctx.stroke();
   box(29, 53, 16, 25, 6, accent);box(75, 53, 16, 25, 6, accent);break;
  case 'fan':
   circle(60, 51, 26, '#fff');
   for (let i = 0; i < 3; i++) {
    ctx.save();ctx.translate(60, 51);ctx.rotate(i * 2 * Math.PI / 3);
    ctx.beginPath();ctx.ellipse(4, -11, 6, 11, .55, 0, 2 * Math.PI);
    ctx.fillStyle = accent;ctx.fill();ctx.restore();
   }
   circle(60, 51, 5, '#fff');path([[60,78],[60,86],[48,86],[72,86]]);break;
  case 'speaker':
   box(29, 35, 32, 40, 8, accent);circle(45, 55, 9, '#fff');
   path([[68,46],[75,55],[68,64]]);path([[80,39],[91,55],[80,71]]);break;
  case 'wave':
   path([[24,55],[96,55]],'#77968e',2);
   path(Array.from({length:73},(_,i)=>[24+i,55-17*Math.sin(i/72*4*Math.PI)]),accent,4);break;
  case 'mic':
   box(49, 27, 22, 42, 11, accent);
   ctx.beginPath();ctx.arc(60, 58, 19, 0, Math.PI);
   ctx.strokeStyle=ink;ctx.lineWidth=3;ctx.stroke();
   path([[60,77],[60,85],[49,85],[71,85]]);break;
  case 'clock':
   circle(60, 54, 25, '#fff');path([[60,36],[60,55],[73,61]],accent,4);
   circle(60, 55, 2, accent);break;
  case 'speech':
   box(32, 33, 56, 37, 12, '#fff');path([[50,70],[42,80],[42,70]]);
   for (const x of [47, 60, 73]) circle(x,52,3,accent);
   break;
  case 'chart':
   path([[32,32],[32,76],[90,76]]);
   path([[37,40],[56,54],[80,63]],accent,4);
   for (const [x,y] of [[37,40],[56,54],[80,63]]) circle(x,y,4,accent);
   break;
  case 'wind':
   path([[26,43],[77,43],[87,36],[87,30],[81,26],[75,30]],accent,4);
   path([[30,55],[90,55]],accent,4);
   path([[39,68],[74,68],[82,75],[78,82],[70,79]],accent,4);break;
 }
}
