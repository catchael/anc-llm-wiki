"""Build the offline lesson from the maintained Markdown, using only stdlib."""
from pathlib import Path
import html
import json
import re
from lesson.slides import SLIDES

ROOT = Path(__file__).resolve().parent


def read_document(path):
    text = path.read_text(encoding='utf-8')
    metadata = {}
    if text.startswith('---\n'):
        front, text = text[4:].split('\n---\n', 1)
        for line in front.splitlines():
            if ':' in line:
                key, value = line.split(':', 1)
                value = value.strip()
                if value.startswith('"'):
                    value = json.loads(value)
                metadata[key] = value
    return metadata, text


def main():
    documents = {}
    concepts = []
    for path in sorted((ROOT / 'wiki').glob('*.md')):
        metadata, body = read_document(path)
        if 'id' in metadata:
            concepts.append((metadata, body, path))
    order = ['W6', 'W1', 'W2', 'W4', 'W3', 'W5', 'W7', 'W8', 'W9']
    if sorted(item[0]['id'] for item in concepts) != sorted(order):
        raise ValueError('Update the lesson reading order when adding Wiki concepts.')
    concepts.sort(key=lambda item: order.index(item[0]['id']))
    for metadata, _, path in concepts:
        documents[path.resolve()] = '#wiki-' + metadata['id'][1:]
    sources = {}
    for path in sorted((ROOT / 'sources').glob('S*/source.md')):
        metadata, _ = read_document(path)
        sources[metadata['id']] = metadata
        documents[path.resolve()] = metadata['source_url']
    documents[(ROOT / 'lesson/outline.md').resolve()] = '#1'
    documents[(ROOT / 'project.md').resolve()] = '#flow'
    documents[(ROOT / 'wiki/index.md').resolve()] = '#wiki'
    documents[(ROOT / 'lesson/index.html').resolve()] = '#1'

    def inline(text, base):
        # All author text is escaped; only generated, validated links add markup.
        def link(target, label):
            if target.startswith(('https://', 'http://')):
                url = target
            elif target.startswith('#'):
                url = target
            else:
                raw_path, _, fragment = target.partition('#')
                candidate = base / raw_path
                if candidate.suffix == '':
                    candidate = candidate.with_suffix('.md')
                candidate = candidate.resolve()
                if not candidate.is_relative_to(ROOT) or (not candidate.exists() and candidate not in documents):
                    raise ValueError(f'Broken local link: {base} -> {target}')
                url = documents.get(candidate, '../' + candidate.relative_to(ROOT).as_posix())
                if fragment and not url.startswith('#'):
                    url += '#' + fragment
            return '<a href="' + html.escape(url, quote=True) + '">' + html.escape(label) + '</a>'
        tokens = []
        def save(value):
            tokens.append(value)
            return f'\x00{len(tokens)-1}\x00'
        text = re.sub(r'\[\[([^\]|]+)(?:\|([^\]]+))?\]\]', lambda m: save(link(m[1], m[2] or m[1].split('/')[-1])), text)
        text = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', lambda m: save(link(m[2], m[1])), text)
        text = html.escape(text)
        text = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', text)
        text = re.sub(r'`([^`]+)`', r'<code>\1</code>', text)
        return re.sub(r'\x00(\d+)\x00', lambda m: tokens[int(m[1])], text)

    def markdown(text, base):
        output, code, table, list_type = [], None, False, None
        for line in text.splitlines():
            item = re.match(r'^(?:([-]) |(\d+)\. )(.*)', line) if code is None else None
            next_list = ('ul' if item[1] else 'ol') if item else None
            if list_type and next_list != list_type:
                output.append(f'</{list_type}>')
                list_type = None
            if line.startswith('```'):
                if code is None:
                    code = []
                else:
                    output.append('<pre style="overflow:auto"><code>' + html.escape('\n'.join(code)) + '</code></pre>')
                    code = None
                continue
            if code is not None:
                code.append(line)
                continue
            if line.startswith('|'):
                if re.fullmatch(r'[|\s:\-]+', line):
                    continue
                if not table:
                    output.append('<div style="overflow:auto"><table>')
                    table = True
                output.append('<tr>' + ''.join('<td style="padding:6px;border-bottom:1px solid #ccc">' + inline(cell.strip(), base) + '</td>' for cell in line.strip('|').split('|')) + '</tr>')
                continue
            if table:
                output.append('</table></div>')
                table = False
            if not line.strip():
                continue
            if item:
                if list_type is None:
                    list_type = next_list
                    output.append(f'<{list_type}>')
                output.append('<li>' + inline(item[3], base) + '</li>')
                continue
            heading = re.match(r'^(#{1,6}) (.*)', line)
            if heading:
                level = min(len(heading[1]) + 1, 6)
                output.append(f'<h{level}>' + inline(heading[2], base) + f'</h{level}>')
            else:
                output.append('<p>' + inline(line, base) + '</p>')
        if table:
            output.append('</table></div>')
        if list_type:
            output.append(f'</{list_type}>')
        if code is not None:
            raise ValueError('Unclosed code block')
        return '\n'.join(output)

    notes, knowledge = [], []
    for metadata, body, path in concepts:
        source_ids = [s.strip() for s in metadata['sources'].strip('[]').split(',')]
        unknown = set(source_ids) - sources.keys()
        if unknown:
            raise ValueError(f"{path.name} references unknown sources: {', '.join(sorted(unknown))}")
        title = metadata['title']
        notes.append([int(metadata['id'][1:]), html.escape(title)])
        # The article already presents this title; render the complete body once.
        knowledge.append(markdown(re.sub(r'^# [^\n]+\n', '', body, count=1), path.parent))
    for page, (_, _, _, refs) in enumerate(SLIDES, 1):
        if not refs or set(refs) - {note[0] for note in notes}:
            raise ValueError(f'Invalid Wiki references on slide {page}: {refs}')
    project = (ROOT / 'project.md').read_text(encoding='utf-8').split('## 歷史操作紀錄')[0]
    workflow = markdown(project, ROOT)
    # The graph is shown as readable source offline; no network Mermaid dependency.
    payloads = {'__NOTES__': notes, '__KNOWLEDGE__': knowledge, '__WORKFLOW__': workflow, '__SLIDES__': SLIDES}
    rendered = (ROOT / 'lesson/template.html').read_text(encoding='utf-8')
    rendered = rendered.replace('__STICKER_CODE__', (ROOT / 'lesson/stickers.js').read_text(encoding='utf-8'))
    for token, value in payloads.items():
        if rendered.count(token) != 1:
            raise ValueError(f'Expected exactly one {token}')
        rendered = rendered.replace(token, json.dumps(value, ensure_ascii=False).replace('<', '\\u003c').replace('\u2028', '\\u2028').replace('\u2029', '\\u2029'))
    (ROOT / 'lesson/index.html').write_text(rendered, encoding='utf-8')
    print(f'Built lesson/index.html: {len(concepts)} concepts, {len(sources)} source records.')


if __name__ == '__main__':
    main()
