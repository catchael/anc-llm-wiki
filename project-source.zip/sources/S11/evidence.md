# S11 核讀記錄

2026-11-21 核讀 [TI SPRA042](https://www.ti.com/lit/an/spra042/spra042.pdf) 的 Filtered-X Least-Mean-Square Algorithm 段落。式 4 表達兩路在測點相加。式 6 是係數與樣本的乘加。式 8 是使用剩餘量與經路徑修正的參考樣本來更新係數。式 10 定義該路徑修正。圖 9 列出轉換、放大及換能元件。本文保存定位與轉述，教學圖另繪。
