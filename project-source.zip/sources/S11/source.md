---
id: S11
title: "Texas Instruments · Design of Active Noise Control Systems With the TMS320 Family"
type: engineering-application-note
source_url: https://www.ti.com/lit/an/spra042/spra042.pdf
source_locator: "SPRA042，內頁 14–18，式 4、6、8、10 及圖 8–9"
status: verified-excerpt
verified_on: 2026-11-21
evidence: evidence.md
---
# 前饋控制與「先估播放路徑，再調係數」

技術文件用管道展示前饋控制。它以目前與先前的收音樣本乘上係數再相加，產生控制輸出。當控制器會依剩餘聲調整係數時，文件把參考訊號先經過估計的次級路徑，再與誤差信號一起用於更新。圖 9 也列出輸出轉換、功率放大、發聲及誤差收音的硬體環節。用來解釋通用原理。耳機上的前饋研究另見 S04，算例為本 Wiki 自行設計。

[本輪閱讀定位](evidence.md) · [[../../wiki/fan-signal-chain]]
