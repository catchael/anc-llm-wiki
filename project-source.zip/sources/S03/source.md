---
id: S03
title: "Sony · Why do I hear sound with noise-cancelling on?"
type: manufacturer-support
source_url: https://www.sony.co.uk/electronics/support/wireless-headphones-bluetooth-headphones/mdr-zx770bn/articles/00256977
source_locator: "Noise cancellation at different pitch levels"
status: read-failed
imported_on: 2026-11-21
verified_on: null
raw_path: null
origin: anc-wiki.md
---
# Sony · Why do I hear sound with noise-cancelling on?

## Problem｜這份資料回答什麼
為什麼旁人說話仍然聽得見？

## Method｜來源如何說明或研究
產品支援頁說明降噪效果與聲音頻率的關係。

## Results｜既有筆記的摘要
持續的低頻引擎聲是常見的降噪情境。說話時，各頻率成分和強弱隨音節變化，其中一部分即使經過衰減，仍可能聽得見。

## Limitations｜適用條件與證據限制
這是常見體感。語音也能衰減，單靠聲源名稱無法預測衰減量。

本頁由既有筆記遷移；本次未重新連線查核，也未保存來源原文。閱讀位置：Noise cancellation at different pitch levels。摘要頁不視為已讀全文。

## 關聯與查核
- 概念：[[../../wiki/speech-residual]]
- 教學整合：[[../../lesson/outline]]
- 原始出處：[線上來源](https://www.sony.co.uk/electronics/support/wireless-headphones-bluetooth-headphones/mdr-zx770bn/articles/00256977)
- 待辦：保存可合法取得的原始資料、核對段落、補 raw_path 與 verified_on，再將 status 改成 verified。

## 本輪讀取結果（2026-11-21）
原 Sony UK 頁面逾時，通用美國網址也未能讀取；不能由此判定永久失效。保留舊筆記作歷史追溯，不作新版概念的已核讀依據。人聲概念改由 S02、S05、S06 支持。
