---
id: S08
title: "An、Wu、Liu（2022）· Feedback Controller Optimization for Active Noise Control Headphones"
type: research-abstract
source_url: https://doi.org/10.3390/app12030977
source_locator: "Appl. Sci. 2022, 12(3), 977，作者摘要"
status: verified-excerpt
verified_on: 2026-11-21
evidence: evidence.md
---
# 回饋麥克風的讀數與耳邊的讀數

## 閱讀紀錄
作者研究回饋麥克風位置和人耳位置之間，聲音傳入與補償聲路徑的頻率反應可能不一致。摘要描述以假人頭部的耳位量測實驗結果。用於 [[../../wiki/microphone-layouts]]「麥克風位置和耳朵位置的差別」。

## 適用範圍
作者摘要支持位置不同可能造成測量差異。未採用特定數字、內部演算法或產品通則。[摘要與定位](evidence.md)。
