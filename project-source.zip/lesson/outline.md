# 從耳機開始的二十一頁教學

目標是讓第一次接觸降噪的讀者，能描述耳罩與電子系統各做了什麼，操作一次聲波抵消練習，再用一個測量例子回答「降噪到底減少多少」。

| 頁 | 教學問題 | 閱讀依據 |
|---|---|---|
| 1 | 音樂和旁人說話怎麼各自到耳朵？ | [[../wiki/headphones]] |
| 2 | 戴上耳機和打開開關各改變什麼？ | [[../wiki/headphones]]、[[../wiki/active-and-passive]] |
| 3 | 空氣的擠壓和放鬆如何傳到耳朵？ | [[../wiki/superposition]]、[[../wiki/headphones]] |
| 4 | 如何用三張同尺度波形，先數波峰再比高度？ | [[../wiki/superposition]]、[[../wiki/phase-and-delay]] |
| 5 | 兩道聲音相加時怎麼算？ | [[../wiki/superposition]] |
| 6 | 按三種錯開量，沿直線比較同一時刻的三排波形 | [[../wiki/superposition]]、[[../wiki/phase-and-delay]] |
| 7 | 麥克風、電子元件和小喇叭怎麼合作？ | [[../wiki/active-and-passive]]、[[../wiki/phase-and-delay]] |
| 8 | 用等寬的毫秒格比較，同樣晚一格佔一輪多少？ | [[../wiki/phase-and-delay]] |
| 9 | 人聲變小後，為什麼還可能聽得懂？ | [[../wiki/speech-residual]]、[[../wiki/measurement]] |
| 10 | 如何公平比較關閉與開啟降噪？ | [[../wiki/active-and-passive]]、[[../wiki/measurement]] |
| 11 | 如何從表格和圖上讀出 100 Hz 的差異？ | [[../wiki/measurement]] |
| 12 | 前饋、回饋、混合各在哪裡收聲？ | [[../wiki/microphone-layouts]] |
| 13 | 內側麥克風與耳道入口的讀數有什麼差別？ | [[../wiki/microphone-layouts]] |
| 14 | 遠處的樹葉聲與掠過耳罩的風為什麼要分開？ | [[../wiki/test-scenarios]] |
| 15 | 從哪一刻記錄？全頻與生活錄音各回答什麼？ | [[../wiki/test-scenarios]]、[[../wiki/phase-and-delay]] |
| 16 | 少 20 dB，原本的聲壓剩幾格？ | [[../wiki/measurement]] |
| 17 | 風扇聲怎麼經過收音、轉換、處理與發聲？ | [[../wiki/fan-signal-chain]]、[[../wiki/active-and-passive]] |
| 18 | 如何量播放路徑？0.4 與真實掃頻量測各代表什麼？ | [[../wiki/fan-signal-chain]] |
| 19 | 如何用兩個風扇時刻求出初始權重？固定濾波器如何設計？ | [[../wiki/fan-signal-chain]]、[[../wiki/active-and-passive]]、[[../wiki/phase-and-delay]] |
| 20 | 重新佩戴後，如何用內側量到的剩餘聲微調兩個權重？ | [[../wiki/fan-signal-chain]]、[[../wiki/microphone-layouts]] |
| 21 | 能用自己的話解釋降噪、零件鏈與選擇測法嗎？ | 前述概念的複習 |

聲音、相位及分貝的算例使用教學假設。查閱 [[../wiki/index]] 可找到每個概念的來源與適用條件。[查核表](audit.md) 記錄逐頁對照與 Wiki 使用率。教學正文在 slides.py，執行根目錄的 `python build.py` 後開啟 [離線簡報](index.html)。
