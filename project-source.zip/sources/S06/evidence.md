# 來源證據：S06

- 核讀日期：2026-11-21。
- 保存形式：短摘錄及公式定位，不是整章快照。
- [16.2](https://openstax.org/books/university-physics-volume-1/pages/16-2-mathematics-of-waves)：式 16.4，波動包含角頻率與初始相位；Problem-Solving Strategy 列出週期及頻率關係。
- [16.5](https://openstax.org/books/university-physics-volume-1/pages/16-5-interference-of-waves)：Superposition and Interference，以及式 16.13 的兩正弦波相加。

16.5 的短摘錄：
> the resulting wave is the superposition of the waves

教學推導使用的關係（自行重述）：f = 1/T；角頻率 ω = 2πf；等振幅同頻波的合成振幅為 2A |cos(φ/2)|。
