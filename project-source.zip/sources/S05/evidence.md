# S05 來源證據

- 核讀日期：2026-11-21。
- [原始頁面](https://www.rtings.com/headphones/tests/isolation)。
- 核讀範圍：Noise Isolation - Full Range；Common Scenarios；Voice Handling。
- 保存形式：短摘錄及閱讀定位，不是完整頁面。

> Both passive and active components of isolation are captured in this test.

摘要與限制見 [來源紀錄](source.md)。
