---
id: S12
title: "Liebich 等（2019）· Acoustic Path Database for ANC In-Ear Headphone Development"
type: primary-measurement-paper
source_url: https://pub.dega-akustik.de/ICA2019/data/articles/000741.pdf
source_locator: "圖 2、§3.1–3.3，並核對 RWTH PANDAR 公開資料說明"
status: verified-excerpt
verified_on: 2026-11-21
evidence: evidence.md
---
# 真實耳機的播放路徑如何量出來？

研究者用 Bose QC20 耳機硬體和外接測量系統，繞開原廠 ANC 電路。以已知的掃頻測試聲作輸入，同步記錄麥克風讀數，從輸入與輸出的頻率成分求路徑。播放路徑量測的一組掃頻長 4.05 秒，取樣率為 48 kHz。資料庫含 23 人的路徑量測，也記錄戴法差異。這是實驗量測程序與公開路徑，無法由此得知 Bose 的原廠控制係數。

[本輪閱讀定位](evidence.md) · [[../../wiki/fan-signal-chain]]
